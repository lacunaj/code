package com.example.myapp;
import com.codename1.components.FloatingActionButton;
import com.codename1.system.Lifecycle;
import com.codename1.ui.FontImage;
import com.codename1.ui.Form;
import com.codename1.ui.layouts.BoxLayout;


public class MySecondApp extends Lifecycle {
    @Override
    public void runApp() {
        new ToDoLayout().show(); //calls ToDoLayout method that shows everything

    }

    public class ToDoLayout extends Form{
        public ToDoLayout(){
            super("Get this done", BoxLayout.y());

            FloatingActionButton.setIconDefaultSize(5); //Changes default button size

            FloatingActionButton addToDo = FloatingActionButton.createFAB(FontImage.MATERIAL_ADD); //Adds button
            addToDo.bindFabToContainer(this);
            addToDo.addActionListener(e -> addNewItem());
        }

        private void addNewItem(){
            
        }

    }

}
